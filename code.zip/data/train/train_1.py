import os
import time

import pandas as pd
from sklearn.model_selection import train_test_split

os.environ["CUDA_VISIBLE_DEVICES"] = "0, 1"
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from train.model821 import Resnet
from loss import FeatureOrthogonalLoss
from train_utils import (
    load_data,
    model_defaults,
    add_dict_to_argparser,
)
import argparse

def train_one_epoch(epoch,model,train_loader,opt,loss_fn,args):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    loss_cosine = FeatureOrthogonalLoss()

    for batch_idx,(inputs,labels) in enumerate(train_loader):
        seg,ceus,bmodel = inputs
        seg,ceus,bmodel,labels = seg.to(args.device),ceus.to(args.device),bmodel.to(args.device),labels.to(args.device)
        opt.zero_grad()
        f1,f2,s_b,s_c,out = model(ceus, bmodel)
        loss_fn1,loss_fn2,loss_fn3 = loss_fn
        if torch.max(seg) > 0.5:
            loss = loss_fn1(out,labels) + 0.5*loss_fn3(torch.sigmoid(f1),seg)
        else:
            loss = loss_fn1(out, labels)

        loss.backward()
        opt.step()

        running_loss += loss.item()
        _, predicted = torch.max(out, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    train_loss = running_loss / len(train_loader)
    train_acc = correct / total
    return train_loss,train_acc

# def test_model(model,test_loader,wts,args):
#     if wts is not None:
#         model.load_state_dict(wts)
#     model.eval()
#     correct = 0
#     total = 0
#
#     with torch.no_grad():
#         for inputs,labels in test_loader:
#             seg,ceus, bmodel = inputs
#             ceus, bmodel, labels = ceus.to(args.device), bmodel.to(args.device), labels.to(
#                 args.device)
#             f1,f2,s_b,s_c,out = model(ceus,bmodel)
#             _, predicted = torch.max(out, 1)
#             total += labels.size(0)
#             correct += (predicted == labels).sum().item()
#     test_acc = correct / total
#     return test_acc

def initialize_weights(m):
    if isinstance(m,nn.Conv3d) or isinstance(m,nn.Linear) or isinstance(m,nn.Conv2d) :
        nn.init.xavier_uniform_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)

def train(dataset,opt,model,loss_fn,args):

        train_dataset,val_dataset,test_dataset = dataset
        avg_test_acc = 0.0
        best_test = 0.0

        train_loader = DataLoader(train_dataset,batch_size=args.batch_size,shuffle=True,num_workers=16)

        val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False,num_workers=16)

        test_loader = DataLoader(test_dataset, batch_size=args.batch_size,shuffle=False,num_workers=16)

        model.apply(initialize_weights)

        best_model_wts = None
        best_val_accuracy = 0.0

        for epoch in range(args.epochs):
            start_time = time.time()
            train_loss,train_acc = train_one_epoch(epoch,model,train_loader,opt,loss_fn,args)
            end_time = time.time()
            elapsed_time = end_time - start_time
            # val_acc = test_model(model, val_loader,None, args)
            # print(f"Epoch [{epoch+1}/{args.epochs}], Trian one epoch time: {elapsed_time:.4f}\n"
            #       f"Train Loss: {train_loss:.4f}, Train Accuracy: {train_acc:.4f},Val Accuracy: {val_acc:.4f}")

            # if val_acc > best_val_accuracy:
            #     best_val_accuracy = val_acc
            #     best_model_wts = model.state_dict()
        print(best_model_wts == None)
        # test_acc = test_model(model, test_loader,best_model_wts, args)
        # torch.save(model.state_dict(), f'train_test/model821_{test_acc}.pth')
        # print(f"Val Accuracy: {best_val_accuracy:.4f},Test Accuracy: {test_acc:.4f}")

        print("All Finished")

def save_model(model, file_path='train_test/ceus_easy_fusion_1.pth'):
    torch.save(model.state_dict(), file_path)
    print(f'Model has been saved to {file_path}')

def create_argparser():
    defaults = dict(
        train_path=r"C:\Users\10528\Desktop\data\dataloader\select_seg.xlsx",
        num_frames = 32,
        select_choice="1",
        lr=1e-4,
        batch_size=4,
        split_size = 0.2,
        seed = 30,
        epochs = 50,
        num_splits = 5,
        log_interval = 1,
        device = "cuda" if torch.cuda.is_available() else "cpu",
        out_dir='./results/'
    )
    defaults.update(model_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser
# 主函数
def main():
    # 创建参数解析器
    parser = create_argparser()
    args = parser.parse_args()

    # 读取 Excel 文件
    file_path = args.train_path
    df = pd.read_excel(file_path)

    # 假设“病历号”是标签列
    X = df[['ID', 'ceus_path', 'bmodel_path','seg_path']]  # 特征数据
    y = df['label']  # 标签数据

    # 分割数据，保持标签平衡
    X_train, X_vt, y_train, y_vt = train_test_split(X, y, test_size=0.2, stratify=y,shuffle=True,
                                                        random_state=37)
    X_val, X_test, y_val, y_test = train_test_split(X_vt, y_vt, test_size=0.5, stratify=y_vt,shuffle=True,
                                                        random_state=10)

    # 合并特征和标签
    train_df = pd.concat([X_train, y_train], axis=1)
    train_df.reset_index(drop=True,inplace=True)

    val_df = pd.concat([X_val, y_val], axis=1)
    val_df.reset_index(drop=True, inplace=True)

    test_df = pd.concat([X_test, y_test], axis=1)
    test_df.reset_index(drop=True, inplace=True)

    # 加载数据
    dataset = load_data(train_df, val_df, test_df, args)

    model = Resnet(in_ch=3,base_ch=4,num_class=2,num_frame=16,blocks_layers=[2,2,2,2],attention_apply=[False,False,False,False],fusion_apply=[],bmodal_apply=[0,1,2,3])

    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
    model = model.to(device = args.device)

    loss_fn1 = nn.CrossEntropyLoss()
    loss_fn2 = nn.CrossEntropyLoss()
    loss_fn3 = nn.BCELoss()
    loss_fn = (loss_fn1,loss_fn2,loss_fn3)
    # loss_fn = nn.BCEWithLogitsLoss()
    # opt = optim.SGD(model.parameters(),lr=5e-4,momentum=0.9,weight_decay=1e-4)
    opt = optim.Adam(model.parameters(),lr=5e-4,weight_decay=1e-4)

    # 训练模型
    train(dataset,opt,model,loss_fn,args)

    # 保存模型
    # save_model(model)

if __name__ == "__main__":
    main()

